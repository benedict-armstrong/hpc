#ifndef WALLTIME_H
#define WALLTIME_H

double walltime();

#endif /* WALLTIME_H */
